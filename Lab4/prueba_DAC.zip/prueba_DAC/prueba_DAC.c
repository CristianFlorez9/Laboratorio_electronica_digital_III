#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/timer.h"
#include <math.h>

// Definición de parámetros
#define FIRST_GPIO 0         // Primer GPIO (usará los pines GPIO 0 al 7 para 8 bits)
#define NUM_BITS 8           // Resolución del DAC (8 bits = 256 niveles)
#define SAMPLES 64           // Cantidad de muestras por ciclo de onda
#define SAMPLE_RATE_HZ 50000 // Frecuencia de muestreo (50 kHz -> ~781 Hz de senoidal)

// Máscara de bits para los 8 GPIOs consecutivos
#define GPIO_MASK (((1u << NUM_BITS) - 1) << FIRST_GPIO)

uint8_t sine_lut[SAMPLES];
volatile uint16_t sample_index = 0;

// Genera la tabla de consulta (LUT) para una onda senoidal
void init_sine_lut(void) {
    for (int i = 0; i < SAMPLES; i++) {
        // Mapea la onda seno de [-1, 1] a la escala de 0 a 255 (8 bits)
        float value = (sinf((2.0f * M_PI * i) / SAMPLES) + 1.0f) * 127.5f;
        sine_lut[i] = (uint8_t)roundf(value);
    }
}

// Callback de interrupción de temporizador: se ejecuta cada SAMPLE_RATE_HZ
bool timer_callback(struct repeating_timer *t) {
    // Escribe de manera atómica todos los bits del DAC en un solo ciclo de reloj
    gpio_put_masked(GPIO_MASK, (uint32_t)sine_lut[sample_index] << FIRST_GPIO);

    sample_index++;
    if (sample_index >= SAMPLES) {
        sample_index = 0;
    }
    return true;
}

int main() {
    stdio_init_all();

    // 1. Inicializar y configurar los pines GPIO elegidos como salida
    gpio_init_mask(GPIO_MASK);
    gpio_set_dir_masked(GPIO_MASK, GPIO_MASK);

    // 2. Precalcular la tabla seno
    init_sine_lut();

    // 3. Configurar el temporizador en microsegundos
    // Intervalo (us) = -1000000 / SAMPLE_RATE_HZ  (el signo negativo da tiempos exactos entre ejecuciones)
    int32_t delay_us = -(1000000 / SAMPLE_RATE_HZ);
    struct repeating_timer timer;
    add_repeating_timer_us(delay_us, timer_callback, NULL, &timer);

    // El procesador se mantiene libre o ejecutando otras tareas
    while (true) {
        tight_loop_contents();
    }

    return 0;
}