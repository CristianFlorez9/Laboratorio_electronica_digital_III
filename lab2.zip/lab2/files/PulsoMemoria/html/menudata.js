/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Archivos",url:"files.html",children:[
{text:"Lista de archivos",url:"files.html"},
{text:"Globales",url:"globals.html",children:[
{text:"Todos",url:"globals.html",children:[
{text:"a",url:"globals.html#index_a"},
{text:"c",url:"globals.html#index_c"},
{text:"d",url:"globals.html#index_d"},
{text:"e",url:"globals.html#index_e"},
{text:"f",url:"globals.html#index_f"},
{text:"g",url:"globals.html#index_g"},
{text:"i",url:"globals.html#index_i"},
{text:"l",url:"globals.html#index_l"},
{text:"m",url:"globals.html#index_m"},
{text:"n",url:"globals.html#index_n"},
{text:"o",url:"globals.html#index_o"},
{text:"p",url:"globals.html#index_p"},
{text:"r",url:"globals.html#index_r"},
{text:"s",url:"globals.html#index_s"},
{text:"t",url:"globals.html#index_t"},
{text:"v",url:"globals.html#index_v"}]},
{text:"Funciones",url:"globals_func.html",children:[
{text:"a",url:"globals_func.html#index_a"},
{text:"c",url:"globals_func.html#index_c"},
{text:"e",url:"globals_func.html#index_e"},
{text:"g",url:"globals_func.html#index_g"},
{text:"i",url:"globals_func.html#index_i"},
{text:"l",url:"globals_func.html#index_l"},
{text:"m",url:"globals_func.html#index_m"},
{text:"o",url:"globals_func.html#index_o"},
{text:"p",url:"globals_func.html#index_p"},
{text:"s",url:"globals_func.html#index_s"},
{text:"v",url:"globals_func.html#index_v"}]},
{text:"Variables",url:"globals_vars.html",children:[
{text:"a",url:"globals_vars.html#index_a"},
{text:"c",url:"globals_vars.html#index_c"},
{text:"d",url:"globals_vars.html#index_d"},
{text:"e",url:"globals_vars.html#index_e"},
{text:"i",url:"globals_vars.html#index_i"},
{text:"l",url:"globals_vars.html#index_l"},
{text:"n",url:"globals_vars.html#index_n"},
{text:"p",url:"globals_vars.html#index_p"},
{text:"s",url:"globals_vars.html#index_s"},
{text:"t",url:"globals_vars.html#index_t"},
{text:"v",url:"globals_vars.html#index_v"}]},
{text:"Enumeraciones",url:"globals_enum.html"},
{text:"Valores de enumeraciones",url:"globals_eval.html"}]}]}]}
